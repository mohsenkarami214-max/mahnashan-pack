import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const gold = Color(0xFFD9A52E);
const ink = Color(0xFF171717);
const cream = Color(0xFFFFF8EF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MahnashanApp());
}

class Product {
  Product({required this.name, required this.category, this.description = '', this.size = ''});
  String name;
  String category;
  String description;
  String size;

  Map<String, dynamic> toJson() => {
    'name': name, 'category': category, 'description': description, 'size': size
  };
  factory Product.fromJson(Map<String, dynamic> json) => Product(
    name: json['name'] ?? '',
    category: json['category'] ?? 'بسته‌بندی رستورانی',
    description: json['description'] ?? '',
    size: json['size'] ?? '',
  );
}

class CatalogStore extends ChangeNotifier {
  static const storageKey = 'mahnashan_products_v1';
  final List<Product> products = [];
  bool loaded = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(storageKey);
    if (raw != null) {
      final decoded = jsonDecode(raw) as List<dynamic>;
      products
        ..clear()
        ..addAll(decoded.map((e) => Product.fromJson(Map<String, dynamic>.from(e))));
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(storageKey, jsonEncode(products.map((p) => p.toJson()).toList()));
    notifyListeners();
  }

  Future<void> add(Product product) async {
    products.add(product);
    await save();
  }

  Future<void> update(int index, Product product) async {
    products[index] = product;
    await save();
  }

  Future<void> remove(int index) async {
    products.removeAt(index);
    await save();
  }
}

class MahnashanApp extends StatefulWidget {
  const MahnashanApp({super.key});
  @override
  State<MahnashanApp> createState() => _MahnashanAppState();
}

class _MahnashanAppState extends State<MahnashanApp> {
  final store = CatalogStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ماهنشان پک',
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: Colors.white),
      fontFamily: 'Roboto',
    ),
    home: Directionality(
      textDirection: TextDirection.rtl,
      child: HomePage(store: store),
    ),
  );
}

const categories = [
  'همه محصولات',
  'بسته‌بندی رستورانی',
  'بسته‌بندی فست‌فود',
  'بسته‌بندی آبمیوه بیرون‌بر',
  'بسته‌بندی بستنی بیرون‌بر',
];

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.store});
  final CatalogStore store;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selected = 0;
  int tab = 0;

  List<Product> get visibleProducts {
    if (selected == 0) return widget.store.products;
    return widget.store.products.where((p) => p.category == categories[selected]).toList();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: const Row(children: [
            Image(image: AssetImage('assets/images/company_logo.jpg'), width: 42, height: 42, fit: BoxFit.contain),
            SizedBox(width: 8),
            Text('ماهنشان پک', style: TextStyle(fontWeight: FontWeight.bold)),
          ]),
          actions: [
            IconButton(
              tooltip: 'پنل مدیریت',
              onPressed: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => AdminPage(store: widget.store))),
              icon: const Icon(Icons.admin_panel_settings_outlined),
            )
          ],
        ),
        body: tab == 0 ? _home() : tab == 1 ? _catalog() : _about(),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'محصولات'),
            NavigationDestination(icon: Icon(Icons.info_outline), label: 'درباره ما'),
          ],
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [ink, Color(0xFF383027)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Image.asset('assets/images/company_logo.jpg', height: 112, fit: BoxFit.contain)),
          const SizedBox(height: 12),
          const Text('بسته‌بندی حرفه‌ای برای کسب‌وکار شما',
            style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Text('کاتالوگ محصولات ماهنشان پک', style: TextStyle(color: gold, fontSize: 15)),
          const SizedBox(height: 16),
          const Icon(Icons.inventory_2_rounded, color: gold, size: 40),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('دسته‌بندی محصولات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: categories.length - 1,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.7),
        itemBuilder: (_, i) => InkWell(
          onTap: () { setState(() { selected = i + 1; tab = 1; }); },
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: gold.withOpacity(.35))),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon([Icons.restaurant, Icons.lunch_dining, Icons.local_drink, Icons.icecream][i],
                color: gold, size: 28),
              const SizedBox(height: 8),
              Text(categories[i + 1], textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 22),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('محصولات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        TextButton(onPressed: () => setState(() => tab = 1), child: const Text('مشاهده همه')),
      ]),
      if (widget.store.products.isEmpty)
        const EmptyCatalog()
      else
        ...widget.store.products.take(4).map((p) => ProductTile(product: p)),
    ],
  );

  Widget _catalog() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('کاتالوگ محصولات', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: List.generate(categories.length, (i) =>
        ChoiceChip(label: Text(categories[i]), selected: selected == i,
          onSelected: (_) => setState(() => selected = i))),
      ),
      const SizedBox(height: 12),
      if (visibleProducts.isEmpty) const EmptyCatalog()
      else ...visibleProducts.map((p) => ProductTile(product: p)),
    ],
  );

  Widget _about() => const Padding(
    padding: EdgeInsets.all(24),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Image.asset('assets/images/company_logo.jpg', width: 230, height: 190, fit: BoxFit.contain),
      SizedBox(height: 16),
      Text('ماهنشان پک', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('کاتالوگ محصولات بسته‌بندی بیرون‌بر', textAlign: TextAlign.center),
      SizedBox(height: 8),
      Text('اطلاعات تماس و معرفی رسمی شرکت پس از دریافت اطلاعات واقعی تکمیل می‌شود.',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class EmptyCatalog extends StatelessWidget {
  const EmptyCatalog({super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: const Column(children: [
      Icon(Icons.inventory_2_outlined, size: 42, color: gold),
      SizedBox(height: 8),
      Text('هنوز محصولی ثبت نشده است'),
      Text('مدیر می‌تواند محصولات واقعی را از پنل مدیریت اضافه کند.',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class ProductTile extends StatelessWidget {
  const ProductTile({super.key, required this.product});
  final Product product;
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      leading: const CircleAvatar(backgroundColor: Color(0xFFFFF0D4),
        child: Icon(Icons.inventory_2_outlined, color: gold)),
      title: Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('${product.category}${product.size.isEmpty ? '' : ' • ${product.size}'}'),
      trailing: const Icon(Icons.chevron_left),
      onTap: () => showDialog(context: context, builder: (_) => AlertDialog(
        title: Text(product.name),
        content: Text(product.description.isEmpty ? 'توضیحات محصول هنوز ثبت نشده است.' : product.description),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('بستن'))],
      )),
    ),
  );
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key, required this.store});
  final CatalogStore store;

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('پنل مدیریت محصولات')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: gold, foregroundColor: ink,
        onPressed: () => _edit(context),
        icon: const Icon(Icons.add), label: const Text('افزودن محصول'),
      ),
      body: AnimatedBuilder(
        animation: store,
        builder: (_, __) => store.products.isEmpty
          ? const Center(child: Text('هنوز محصولی ثبت نشده است'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: store.products.length,
              itemBuilder: (_, i) => Card(child: ListTile(
                title: Text(store.products[i].name),
                subtitle: Text(store.products[i].category),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'edit') _edit(context, index: i, product: store.products[i]);
                    if (v == 'delete') store.remove(i);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('ویرایش')),
                    PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
              )),
            ),
      ),
    ),
  );

  Future<void> _edit(BuildContext context, {int? index, Product? product}) async {
    final name = TextEditingController(text: product?.name ?? '');
    final description = TextEditingController(text: product?.description ?? '');
    final size = TextEditingController(text: product?.size ?? '');
    String category = product?.category ?? categories[1];
    await showDialog(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: Text(product == null ? 'افزودن محصول' : 'ویرایش محصول'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام محصول')),
          DropdownButtonFormField<String>(
            value: category, decoration: const InputDecoration(labelText: 'دسته‌بندی'),
            items: categories.skip(1).map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) { if (v != null) setLocal(() => category = v); },
          ),
          TextField(controller: size, decoration: const InputDecoration(labelText: 'ابعاد / مشخصات')),
          TextField(controller: description, maxLines: 3,
            decoration: const InputDecoration(labelText: 'توضیحات')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              final p = Product(name: name.text.trim(), category: category,
                size: size.text.trim(), description: description.text.trim());
              if (index == null) { await store.add(p); } else { await store.update(index, p); }
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('ذخیره'),
          ),
        ],
      ),
    ));
  }
}
