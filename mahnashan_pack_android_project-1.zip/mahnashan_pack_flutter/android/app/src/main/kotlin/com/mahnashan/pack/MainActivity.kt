package com.mahnashan.pack

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
